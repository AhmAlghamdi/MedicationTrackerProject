
package medicationtrackerapplication;


import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;
public class MedicationManager {

    private ArrayList<Medication> meds = new ArrayList<>();
    private Timer timer;

    // 1) Add Medication
    public void addMedication(String name, String dosage, String schedule) {
        Medication m = new Medication(name, dosage, schedule);
        meds.add(m);
    }

    // 2) Update Dose Status
    public boolean updateDoseStatus(String name, String status) {
        for (Medication m : meds) {
            if (m.getName().equalsIgnoreCase(name)) {
                m.setStatus(status);
                return true;
            }
        }
        return false;
    }

    // 3) Generate Report File
    public boolean generateReport() {
        try {
            FileWriter fw = new FileWriter("medication_report.txt");
            fw.write("==== Medication Report ====\n\n");
            for (Medication m : meds) {
                fw.write(m.toString() + "\n");
            }
            fw.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // 4) Start Reminder Service (simple scheduler)
    public void startReminderService() {
        if (timer != null) {
            return; // already running
        }

        timer = new Timer();

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                checkReminders();
            }
        }, 0, 5000); // checking every 5 seconds
    }

   private void checkReminders() {
    Calendar now = Calendar.getInstance();
    String currentTime = String.format("%02d:%02d",
            now.get(Calendar.HOUR_OF_DAY),
            now.get(Calendar.MINUTE));

    for (Medication m : meds) {

        // the notification only appear if the state is pending 
      
        if (m.getSchedule().equals(currentTime) && m.getStatus().equals("Pending")) {

            
            m.setStatus("Reminded");

            // Popup Reminder
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(
                        null,
                        " Reminder:\nIt's time to take: " + m.getName() +
                                "\nDosage: " + m.getDosage(),
                        "Medication Reminder",
                        JOptionPane.INFORMATION_MESSAGE
                );
            });
        }
    }
}

    public List<Medication> getMedications() {
        return Collections.unmodifiableList(meds);
    }
}
