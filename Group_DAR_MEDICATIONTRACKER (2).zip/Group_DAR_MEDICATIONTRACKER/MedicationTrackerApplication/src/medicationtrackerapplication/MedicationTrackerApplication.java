package medicationtrackerapplication;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MedicationTrackerApplication extends JFrame {

    private MedicationManager manager;

    
    private JTextField nameField;
    private JTextField dosageField;
    private JTextField scheduleField;

    
    private JTextField updateNameField;
    private JComboBox<String> statusCombo;

     
    private DefaultTableModel tableModel;
    private JTable medsTable;

    public MedicationTrackerApplication() {
        super("Medication Tracker");

        manager = new MedicationManager();
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null); 
        setLayout(new BorderLayout());

        
        JPanel addPanel = new JPanel(new GridLayout(2, 4, 5, 5));
        addPanel.setBorder(BorderFactory.createTitledBorder("Add Medication"));

        nameField = new JTextField();
        dosageField = new JTextField();
        scheduleField = new JTextField(); // HH:MM

        JButton addButton = new JButton("Add");

        addPanel.add(new JLabel("Name:"));
        addPanel.add(nameField);
        addPanel.add(new JLabel("Dosage:"));
        addPanel.add(dosageField);
        addPanel.add(new JLabel("Schedule (HH:MM):"));
        addPanel.add(scheduleField);
        addPanel.add(new JLabel());
        addPanel.add(addButton);

        
        JPanel updatePanel = new JPanel(new GridLayout(2, 3, 5, 5));
        updatePanel.setBorder(BorderFactory.createTitledBorder("Update Dose Status"));

        updateNameField = new JTextField();
        statusCombo = new JComboBox<>(new String[] {"Taken", "Missed", "Pending"});
        JButton updateButton = new JButton("Update Status");

        updatePanel.add(new JLabel("Medication Name:"));
        updatePanel.add(updateNameField);
        updatePanel.add(statusCombo);
        updatePanel.add(new JLabel());
        updatePanel.add(updateButton);
        updatePanel.add(new JLabel());

       
        JPanel bottomButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton generateReportButton = new JButton("Generate Report");
        JButton startReminderButton = new JButton("Start Reminders");

        bottomButtonsPanel.add(startReminderButton);
        bottomButtonsPanel.add(generateReportButton);

        
        tableModel = new DefaultTableModel(
                new Object[]{"Name", "Dosage", "Time", "Status"}, 0);
        medsTable = new JTable(tableModel);
        JScrollPane tableScroll = new JScrollPane(medsTable);
        tableScroll.setBorder(
                BorderFactory.createTitledBorder("Medications List"));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(addPanel, BorderLayout.NORTH);
        topPanel.add(updatePanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);
        add(bottomButtonsPanel, BorderLayout.SOUTH);

        // ======= Button Events =======

        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String dosage = dosageField.getText().trim();
            String time = scheduleField.getText().trim();

            if (name.isEmpty() || dosage.isEmpty() || time.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please fill all fields.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            manager.addMedication(name, dosage, time);
            refreshTable();
            clearAddFields();

            JOptionPane.showMessageDialog(this,
                    "Medication added successfully!");
        });

        updateButton.addActionListener(e -> {
            String medName = updateNameField.getText().trim();
            String status = (String) statusCombo.getSelectedItem();

            if (medName.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter medication name.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean updated = manager.updateDoseStatus(medName, status);
            if (updated) {
                refreshTable();
                JOptionPane.showMessageDialog(this,
                        "Status updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Medication not found.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        generateReportButton.addActionListener(e -> {
            boolean ok = manager.generateReport();
            if (ok) {
                JOptionPane.showMessageDialog(this,
                        "Report generated: medication_report.txt");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Error generating report.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        startReminderButton.addActionListener(e -> {
            manager.startReminderService();
            JOptionPane.showMessageDialog(this,
                    "Reminder service started.\nCheck console output for reminders.");
        });
    }

    private void refreshTable() {
        tableModel.setRowCount(0);

        List<Medication> meds = manager.getMedications();
        for (Medication m : meds) {
            tableModel.addRow(new Object[]{
                    m.getName(),
                    m.getDosage(),
                    m.getSchedule(),
                    m.getStatus()
            });
        }
    }

    private void clearAddFields() {
        nameField.setText("");
        dosageField.setText("");
        scheduleField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MedicationTrackerApplication app = new MedicationTrackerApplication();
            app.setVisible(true);
        });
    }
}
