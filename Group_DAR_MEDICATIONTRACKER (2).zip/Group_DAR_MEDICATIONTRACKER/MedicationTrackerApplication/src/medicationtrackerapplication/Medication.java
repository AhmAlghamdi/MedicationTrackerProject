
package medicationtrackerapplication;


public class Medication {
    private String name;
    private String dosage;
    private String schedule; // HH:MM
    private String status;   // Pending / Taken / Missed

    public Medication(String name, String dosage, String schedule) {
        this.name = name;
        this.dosage = dosage;
        this.schedule = schedule;
        this.status = "Pending";
    }

    public String getName() { return name; }
    public String getDosage() { return dosage; }
    public String getSchedule() { return schedule; }
    public String getStatus() { return status; }

    public void setStatus(String s) { this.status = s; }

    @Override
    public String toString() {
        return name + " | Dosage: " + dosage +
               " | Time: " + schedule +
               " | Status: " + status;
    }
}