package medicationtrackerapplication;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.io.File;

public class MedicationManagerTest {

    private MedicationManager manager;

    @Before
    public void setUp() {
        manager = new MedicationManager();
    }

    // Test 1: Add Medication
    @Test
    public void testAddMedication() {
        manager.addMedication("Panadol", "500mg", "08:30");

        assertEquals(1, manager.getMedications().size());
        assertEquals("Panadol", manager.getMedications().get(0).getName());
        assertEquals("Pending", manager.getMedications().get(0).getStatus());
    }

    // Test 2: Update Medication Status
    @Test
    public void testUpdateStatus() {
        manager.addMedication("Vitamin C", "1000mg", "09:00");

        boolean updated = manager.updateDoseStatus("Vitamin C", "Taken");

        assertTrue(updated);
        assertEquals("Taken", manager.getMedications().get(0).getStatus());
    }

    // Test 3: Generate Report File
    @Test
    public void testGenerateReport() {
        manager.addMedication("Aspirin", "81mg", "10:00");

        boolean success = manager.generateReport();

        assertTrue(success);

        File file = new File("medication_report.txt");
        assertTrue(file.exists());
    }

    // Test 4: Reminder Logic (Mock)
    @Test
    public void testReminderMock() {
        String fakeTime = "12:00";
        manager.addMedication("TestDrug", "20mg", fakeTime);

        Medication med = manager.getMedications().get(0);
        med.setStatus("Pending");

        if (med.getSchedule().equals(fakeTime) && med.getStatus().equals("Pending")) {
            med.setStatus("Reminded");
        }

        assertEquals("Reminded", med.getStatus());
    }
}
